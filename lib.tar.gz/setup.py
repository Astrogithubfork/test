import os
output = os.system('id')
print(output)
